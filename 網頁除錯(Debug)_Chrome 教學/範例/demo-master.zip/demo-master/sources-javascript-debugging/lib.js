function lib() {
  console.log('Hello from A awesome lib.');
}
